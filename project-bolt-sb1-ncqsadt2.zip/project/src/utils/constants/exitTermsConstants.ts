export const ENGAGEMENT_PERIOD = 5;
export const SUBSCRIPTION_DURATIONS = [25, 20, 15, 10] as const;
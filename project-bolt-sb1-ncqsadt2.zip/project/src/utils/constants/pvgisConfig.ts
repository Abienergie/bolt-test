export const PVGIS_CONFIG = {
  pvtechchoice: 'crystSi',
  mountingplace: 'free',
  browser: '1',
  trackingtype: 0,
  components: 1
} as const;
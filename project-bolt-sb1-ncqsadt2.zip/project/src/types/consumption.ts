export interface ConsumptionData {
  prm: string;
  date: string;
  peakHours: number;
  offPeakHours: number;
}